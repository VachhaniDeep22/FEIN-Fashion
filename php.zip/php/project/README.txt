database name : ecom
admin id: FEIN
admin password : feinadmin

 